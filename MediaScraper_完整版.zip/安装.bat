﻿@echo off
chcp 65001 ^>nul
title MediaScraper 安装向导
echo ========================================
echo    MediaScraper 安装
echo ========================================
echo.
echo [1/3] 正在检查Python...
python --version ^>nul 2^>^&1
if errorlevel 1 (
    echo [错误] 未找到Python！
    echo 请先安装Python 3.8或更高版本
    echo https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
python --version
echo [OK] Python已就绪
echo.
echo [2/3] 正在检查ffmpeg...
if exist "ffmpeg.exe" (
    echo [OK] ffmpeg已存在
) else (
    echo [提示] 未找到ffmpeg.exe
    echo 请查看 ffmpeg安装说明.txt
    echo 视频可能没有声音
)
echo.
echo [3/3] 正在安装依赖...
pip install -r requirements.txt
echo.
echo ========================================
echo    安装完成！
echo ========================================
echo.
echo 现在双击"启动.bat"即可运行程序
echo.
pause
